import connection from "../config/connectDB";
import winGoController from "./winGoController";
import k5Controller from "./k5Controller";
import k3Controller from "./k3Controller";
import cron from 'node-cron';
const axios = require('axios');
// const cron = require('node-cron');
// const mysql = require('mysql');
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const cronJobGame1p = (io) => {
    cron.schedule('*/1 * * * *', async () => {
        await winGoController.addWinGo(1);
        await winGoController.handlingWinGo1P(1);
        const [winGo1] = await connection.execute('SELECT * FROM `wingo` WHERE `game` = "wingo" ORDER BY `id` DESC LIMIT 2 ', []);
        const data = winGo1; // Cầu mới chưa có kết quả
        io.emit('data-server', { data: data });

        await k5Controller.add5D(1);
        await k5Controller.handling5D(1);
        const [k5D] = await connection.execute('SELECT * FROM 5d WHERE `game` = 1 ORDER BY `id` DESC LIMIT 2 ', []);
        const data2 = k5D; // Cầu mới chưa có kết quả
        io.emit('data-server-5d', { data: data2, 'game': '1' });

        await k3Controller.addK3(1);
        await k3Controller.handlingK3(1);
        const [k3] = await connection.execute('SELECT * FROM k3 WHERE `game` = 1 ORDER BY `id` DESC LIMIT 2 ', []);
        const data3 = k3; // Cầu mới chưa có kết quả
        io.emit('data-server-k3', { data: data3, 'game': '1' });
    });
    cron.schedule('*/3 * * * *', async () => {
        await winGoController.addWinGo(3);
        await winGoController.handlingWinGo1P(3);
        const [winGo1] = await connection.execute('SELECT * FROM `wingo` WHERE `game` = "wingo3" ORDER BY `id` DESC LIMIT 2 ', []);
        const data = winGo1; // Cầu mới chưa có kết quả
        io.emit('data-server', { data: data });

        await k5Controller.add5D(3);
        await k5Controller.handling5D(3);
        const [k5D] = await connection.execute('SELECT * FROM 5d WHERE `game` = 3 ORDER BY `id` DESC LIMIT 2 ', []);
        const data2 = k5D; // Cầu mới chưa có kết quả
        io.emit('data-server-5d', { data: data2, 'game': '3' });

        await k3Controller.addK3(3);
        await k3Controller.handlingK3(3);
        const [k3] = await connection.execute('SELECT * FROM k3 WHERE `game` = 3 ORDER BY `id` DESC LIMIT 2 ', []);
        const data3 = k3; // Cầu mới chưa có kết quả
        io.emit('data-server-k3', { data: data3, 'game': '3' });
    });
    const fetchLatestBlock = async (type, value) => {
        // console.log("Entering fetchLatestBlock function...");
        // console.log("value is....", value)
        try {
            const fetchDataQuery = `SELECT block+${value} as block FROM trx WHERE type=${type} ORDER BY block DESC LIMIT 1`;
            // Execute query using await
            const [rows, fields] = await connection.execute(fetchDataQuery);
            if (rows.length > 0) {
                const latestBlock = rows[0].block;
                // console.log("Latest block fetched:", latestBlock);
                return latestBlock;
            } else {
                // console.log("No blocks found in trx table.");
                return null;
            }
        } catch (error) {
            console.error('Error fetching latest block:', error);
            throw error;
        }
    };
    fetchLatestBlock()
        .then(latestBlock => {
            // console.log("Latest block:", latestBlock);
        })
        .catch(error => {
            console.error("Error:", error);
        });

// Function to generate a unique ID with 17 characters
function generateUniqueID() {
    // Get the current time in Asia/Kolkata time zone
    const now = new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' });
    const date = new Date(now);
    // console.log("date is ...",date)

    // Get the full year
    const year = date.getFullYear().toString();

    // Get the month (zero padded)
    const month = ('0' + (date.getMonth() + 1)).slice(-2);

    // Get the date (zero padded)
    const day = ('0' + date.getDate()).slice(-2);

    // Get the hours, minutes, and seconds
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();

    // Calculate the total minutes since midnight
    const totalMinutes = (hours * 60) + minutes+1;
    console.log("total minute is ....",totalMinutes)

    // Convert total minutes and seconds to a zero-padded string
    const timePeriod = ('00000' + totalMinutes).slice(-5);

    // Concatenate parts to form the unique ID
    const uniqueID = `${year}${month}${day}${timePeriod}`;

    return uniqueID;
}
const id = generateUniqueID();
console.log("Generated ID:", id);

    cron.schedule('*/1 * * * *', async () => {
        try {
            const [trxgetData] = await connection.execute('SELECT * FROM trx WHERE type = 1 ORDER BY id DESC LIMIT 10', []);
            const trxdata = trxgetData.map(item => {
                // Update hash to show only the last 6 characters
                item.hash = item.hash.slice(-4);
              
                // Update time to show only the time part (HH:mm:ss)
                item.time = item.time.split(' ')[1];
              
                // Format period field as per your requirement
                const formattedPeriod = `202**${item.period.toString().slice(-4)}`;
                item.period = formattedPeriod;
              
                // Return the modified item
                return item;
              });
            // console.log("trxdata...", trxdata)
            io.emit('data-server-trx', { data: trxdata });
            const [trxgetperiod] = await connection.execute('SELECT * FROM trx WHERE type = 1 ORDER BY id DESC LIMIT 1', []);
            // console.log("trxgetperiod...",trxgetperiod[0].period);
            const trxPeriodData=trxgetperiod[0].period +1;
            // console.log("trx period data with + 1 value ....",trxPeriodData)
            io.emit('data-server-trx-get-period', { data: trxPeriodData });
            await sleep(56000);
            const latestBlock = await fetchLatestBlock(1, 20);
            // console.log("Latest block DATA IS ..:", latestBlock);
            
            // console.log(".................");

            // const response = await axios.get('https://codunia.com/trx.php', {
            //     params: {
            //         blockNumber: latestBlock
            //     }
            // });
            // // Log the entire API response to debug the structure
            // // console.log('API Response:', response.data);
            // const data = response.data;
            // // Extract required fields from the API response
            // const block = data.BlockHeight;
            // const hash = data.Hash;
            // const result = data.result;
            // if(!block){
            //     console.log("block is not found show undefin...")
            // }
            // const time = new Date().toISOString().slice(0, 19).replace('T', ' '); // Current timestamp
            // Get the current local time in the desired format
 // Get the current local time, subtract 3 seconds, and create a new Date object
 const response = await axios.get('https://apilist.tronscan.org/api/block', {
    params: {
        number: latestBlock
    }
});
const data = response.data.data[0];
const block = data.number;
console.log("block details ....",block)
const hash = data.hash;
console.log("hash send data ...",hash)
function findLastIntegerDigit(hash) {
    for (let i = hash.length - 1; i >= 0; i--) {
        if (!isNaN(hash[i]) && hash[i] !== ' ') {
            return hash[i];
        }
    }
    return null;
}
const  result= findLastIntegerDigit(hash);
console.log("Last integer digit in hash:", result);
 const currentTime = new Date();
 const adjustedTime = new Date(currentTime.getTime() - 3000);

 // Get the local time in the desired format
//  const time = adjustedTime.toLocaleString('en-GB', {
//      year: 'numeric',
//      month: '2-digit',
//      day: '2-digit',
//      hour: '2-digit',
//      minute: '2-digit',
//      second: '2-digit'
//  }).replace(',', '');

//  console.log("send data as....",uniqueID, block, hash, result, bigsmall, formattedTime, status, singleType)
//  // Format the time string to match "YYYY-MM-DD HH:MM:SS"
//  const formattedTime = time.replace(/(\d{2})\/(\d{2})\/(\d{4}),\s(\d{2}):(\d{2}):(\d{2})/, '$3-$2-$1 $4:$5:$6');

const options = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZone: 'Asia/Kolkata'
};

// Get the local time in the desired format
const time = new Intl.DateTimeFormat('en-GB', options).format(adjustedTime).replace(',', '');

// Format the time string to match "YYYY-MM-DD HH:MM:SS"
const formattedTime = time.replace(/(\d{2})\/(\d{2})\/(\d{4}),\s(\d{2}):(\d{2}):(\d{2})/, '$3-$2-$1 $4:$5:$6');
            console.log("time is ....",formattedTime)
            const bigsmall = result <= 4 ? 'small' : 'big';
            const status = 0;
            const singleType = 1;
            // SQL query to insert data
            const uniqueID = generateUniqueID();
            // console.log("uniqueId .....",uniqueID)
            const query = 'INSERT INTO trx (period, block, hash, result, bigsmall, time, status,type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
            const values = [uniqueID, block, hash, result, bigsmall, formattedTime, status, singleType]; // Assuming period can be null or auto-increment
            // Execute the query and handle potential errors
            connection.query(query, values, (err, results) => {
                if (err) {
                    console.error('Error inserting data:', err);
                    return;
                }
                console.log('Data inserted:', results.insertId);
            });
        } catch (error) {
            console.error('Error fetching data from API:', error);
        }
    });
    ////////
    const getLatestBlock = async () => {
        try {
            const [rows] = await connection.query('SELECT * FROM trx WHERE type=1 ORDER BY id DESC LIMIT 1');
            if (rows.length > 0) {
                return rows[0];
            } else {
                return null;
            }
        } catch (error) {
            console.error('Error fetching latest block:', error);
            return null;
        }
    };
    
    const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
    
    const performIncrementalOperation = async () => {
        const latestBlock = await getLatestBlock();
        if (!latestBlock) {
            console.error('No block data found');
            return;
        }
    
        let currentBlock = latestBlock.block;
        let currentTimeString = latestBlock.time;
        let [datePart, timePart] = currentTimeString.split(' '); // Split date and time parts
        let [day, month, year] = datePart.split('/').map(Number); // Split and parse date parts
        let [hours, minutes, seconds] = timePart.split(':').map(Number); // Split and parse time parts
        const secondIncrement = Math.floor(seconds / 3); // Increment value based on the given logic
    
        let iterationCount = 0;
        const totalIterations = 20;
        const resultsHistory = []; // Array to store the last 5 results
    
        const intervalId = setInterval(async () => {
            iterationCount++;
            currentBlock += 1;
            seconds += secondIncrement;
            if (seconds >= 60) {
                minutes += Math.floor(seconds / 60);
                seconds = seconds % 60;
            }
            if (minutes >= 60) {
                hours += Math.floor(minutes / 60);
                minutes = minutes % 60;
            }
            if (hours >= 24) {
                hours = hours % 24;
            }
    
            const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`; // Format time as HH:mm:ss
    
            try {
                const response = await axios.get('https://codunia.com/trx.php', {
                    params: {
                        blockNumber: currentBlock
                    }
                });
                
                const data = response.data;
                const results = data.result;
                const bigsmall = results <= 4 ? 'small' : 'big';
                let blockData = {
                    block: currentBlock,
                    time: formattedTime,
                    result: results,
                    bigsmall: bigsmall
                };
    
                // Add the new result to the history array
                resultsHistory.push(blockData);
    
                // Keep only the last 5 results
                if (resultsHistory.length > 10) {
                    resultsHistory.shift();
                }
    
                io.emit('data-server-trx-three-secound', { data: resultsHistory }); // Emit the history of the last 5 results
                console.log('Block:', blockData);
            } catch (error) {
                console.error('Error fetching block result:', error);
            }
    
            if (iterationCount >= totalIterations) {
                clearInterval(intervalId); // Clear the interval after 20 iterations
                console.log('Completed 20 intervals, waiting for 60 seconds before fetching new data...');
                await delay(15000); // Wait for 60 seconds
                performIncrementalOperation(); // Recursively call to restart the process
            }
        }, 2000); // Run every 2 seconds
    };
    
    // const getLatestBlock = async () => {
    //     try {
    //         const [rows] = await connection.query('SELECT * FROM trx WHERE type=1 ORDER BY id DESC LIMIT 1');
    //         if (rows.length > 0) {
    //             return rows[0];
    //         } else {
    //             return null;
    //         }
    //     } catch (error) {
    //         console.error('Error fetching latest block:', error);
    //         return null;
    //     }
    // };
    
    // const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
    
    // const performIncrementalOperation = async () => {
    //     const latestBlock = await getLatestBlock();
    //     if (!latestBlock) {
    //         console.error('No block data found');
    //         return;
    //     }
    
    //     let currentBlock = latestBlock.block;
    //     let currentTimeString = latestBlock.time;
    //     let [datePart, timePart] = currentTimeString.split(' '); // Split date and time parts
    //     let [day, month, year] = datePart.split('/').map(Number); // Split and parse date parts
    //     let [hours, minutes, seconds] = timePart.split(':').map(Number); // Split and parse time parts
    //     const secondIncrement = Math.floor(seconds / 3); // Increment value based on the given logic
    
    //     let iterationCount = 0;
    //     const totalIterations = 20;
    //     const resultsHistory = []; // Array to store the last 5 results
    
    //     const intervalId = setInterval(async () => {
    //         iterationCount++;
    //         currentBlock += 1;
    //         seconds += secondIncrement;
    //         if (seconds >= 60) {
    //             minutes += Math.floor(seconds / 60);
    //             seconds = seconds % 60;
    //         }
    //         if (minutes >= 60) {
    //             hours += Math.floor(minutes / 60);
    //             minutes = minutes % 60;
    //         }
    //         if (hours >= 24) {
    //             hours = hours % 24;
    //         }
    
    //         const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`; // Format time as HH:mm:ss
    
    //         try {
    //             const response = await axios.get('https://codunia.com/trx.php', {
    //                 params: {
    //                     blockNumber: currentBlock
    //                 }
    //             });
    //             const data = response.data;
    //             const results = data.result;

    //             const bigsmall = results <= 4 ? 'small' : 'big';
    //             let blockData = {
    //                 block: currentBlock,
    //                 time: formattedTime,
    //                 result: results,
    //                 bigsmall: bigsmall
    //             };
    
    //             // Add the new result to the history array
    //             resultsHistory.push(blockData);
    
    //             // Keep only the last 5 results
    //             if (resultsHistory.length > 10) {
    //                 resultsHistory.shift();
    //             }
    
    //             io.emit('data-server-trx-three-secound', { data: resultsHistory }); // Emit the history of the last 5 results
    //             // console.log('Block:', blockData);
    //         } catch (error) {
    //             console.error('Error fetching block result:', error);
    //         }
    
    //         if (iterationCount >= totalIterations) {
    //             clearInterval(intervalId); // Clear the interval after 20 iterations
    //             console.log('Completed 20 intervals, waiting for 60 seconds before fetching new data...');
    //             await delay(15000); // Wait for 60 seconds
    //             performIncrementalOperation(); // Recursively call to restart the process
    //         }
    //     }, 2000); // Run every 2 seconds
    // };
    
    // Start the first cycle
    performIncrementalOperation();
    // const getLatestBlock = async () => {
    //     try {
    //         const [rows] = await connection.query('SELECT * FROM trx WHERE type=1 ORDER BY id DESC LIMIT 1');
    //         if (rows.length > 0) {
    //             return rows[0];
    //         } else {
    //             return null;
    //         }
    //     } catch (error) {
    //         console.error('Error fetching latest block:', error);
    //         return null;
    //     }
    // };
    
    // const performIncrementalOperation = async () => {
    //     const latestBlock = await getLatestBlock();
    //     if (!latestBlock) {
    //         console.error('No block data found');
    //         return;
    //     }
    
    //     let currentBlock = latestBlock.block;
    //     let currentTimeString = latestBlock.time;
    //     let [datePart, timePart] = currentTimeString.split(' '); // Split date and time parts
    //     let [day, month, year] = datePart.split('/').map(Number); // Split and parse date parts
    //     let [hours, minutes, seconds] = timePart.split(':').map(Number); // Split and parse time parts
    //     const secondIncrement = Math.floor(seconds / 3); // Increment value based on the given logic
    
    //     let iterationCount = 0;
    //     const totalIterations = 20;
    //     const resultsHistory = []; // Array to store the last 5 results
    
    //     const intervalId = setInterval(async () => {
    //         iterationCount++;
    //         currentBlock += 1;
    //         seconds += secondIncrement;
    //         if (seconds >= 60) {
    //             minutes += Math.floor(seconds / 60);
    //             seconds = seconds % 60;
    //         }
    //         if (minutes >= 60) {
    //             hours += Math.floor(minutes / 60);
    //             minutes = minutes % 60;
    //         }
    //         if (hours >= 24) {
    //             hours = hours % 24;
    //         }
    
    //         const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`; // Format time as HH:mm:ss
    
    //         try {
    //             const response = await axios.get('https://codunia.com/trx.php', {
    //                 params: {
    //                     blockNumber: currentBlock
    //                 }
    //             });
    //             const data = response.data;
    //             const results = data.result;
    //             const bigsmall = results <= 4 ? 'small' : 'big';
    //             let blockData = {
    //                 block: currentBlock,
    //                 time: formattedTime,
    //                 result: results,
    //                 bigsmall: bigsmall
    //             };
    
    //             // Add the new result to the history array
    //             resultsHistory.push(blockData);
    
    //             // Keep only the last 5 results
    //             if (resultsHistory.length > 5) {
    //                 resultsHistory.shift();
    //             }
    
    //             io.emit('data-server-trx-three-secound', { data: resultsHistory }); // Emit the history of the last 5 results
    //             console.log('Block:', blockData);
    //         } catch (error) {
    //             console.error('Error fetching block result:', error);
    //         }
    
    //         if (iterationCount >= totalIterations) {
    //             clearInterval(intervalId); // Clear the interval after 20 iterations
    //             performIncrementalOperation(); // Recursively call to restart the process
    //         }
    //     }, 3000);
    // };
    
    // // Start the first cycle
    // performIncrementalOperation();
    
    
//     const getLatestBlock = async () => {
//     try {
//         const [rows] = await connection.query('SELECT * FROM trx WHERE type=1 ORDER BY id DESC LIMIT 1');
//         if (rows.length > 0) {
//             return rows[0];
//         } else {
//             return null; 
//         }
//     } catch (error) {
//         console.error('Error fetching latest block:', error);
//         return null;
//     }
// };

// (async () => {
//     const latestBlock = await getLatestBlock();
//     if (!latestBlock) {
//         console.error('No block data found');
//         return;
//     }

//     let currentBlock = latestBlock.block;
//     // let currentBlock = 63372891;
//     let currentTimeString = latestBlock.time;
//     let [datePart, timePart] = currentTimeString.split(' '); // Split date and time parts
//     let [day, month, year] = datePart.split('/').map(Number); // Split and parse date parts
//     let [hours, minutes, seconds] = timePart.split(':').map(Number); // Split and parse time parts
//     const secondIncrement = Math.floor(seconds / 3); // Increment value based on the given logic

//     let iterationCount = 0;
//     const totalIterations = 20;

//     setInterval(async () => {
//         iterationCount++;
//         currentBlock += 1; 
//         seconds += secondIncrement; 
//         if (seconds >= 60) {
//             minutes += Math.floor(seconds / 60);
//             seconds = seconds % 60;
//         }
//         if (minutes >= 60) {
//             hours += Math.floor(minutes / 60);
//             minutes = minutes % 60;
//         }
//         if (hours >= 24) {
//             hours = hours % 24;
//         }

//         if (iterationCount >= totalIterations) {
//             try {
//                 const response = await axios.get('https://codunia.com/trx.php', {
//                     params: {
//                         blockNumber: currentBlock
//                     }
//                 });
//                 const data = response.data;
//                 const result = data.result;
//                 const bigsmall = result <= 4 ? 'small' : 'big';
//                 const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`; // Format time as HH:mm:ss
//                 const blockData = {
//                     block: currentBlock, 
//                     time: formattedTime,
//                     result: result,
//                     bigsmall:bigsmall
//                 };
//                 io.emit('data-server-trx-three-secound', { data: [blockData] }); // Emit the final block data
//                 console.log('Block:', blockData);
                
//                 iterationCount = 0; // Reset the iteration count for the next minute
//             } catch (error) {
//                 console.error('Error fetching block result:', error);
//             }
//         }
//     }, 3000); 
// })();


    // const getLatestBlock = async () => {
    //     try {
    //         const [rows] = await connection.query('SELECT * FROM trx WHERE type=1 ORDER BY id DESC LIMIT 1');
    //         console.log("rows data is ...", rows);
    //         if (rows.length > 0) {
    //             return rows[0];
    //         } else {
    //             return null; 
    //         }
    //     } catch (error) {
    //         console.error('Error fetching latest block:', error);
    //         return null;
    //     }
    // };
    
    // (async () => {
    //     console.log('Entering fetchLatestBlock function...');
    //     const latestBlock = await getLatestBlock();
    //     if (!latestBlock) {
    //         console.error('No block data found');
    //         return;
    //     }
    //     let currentBlock = latestBlock.block;
    //     let currentTimeString = latestBlock.time;
    //     let [datePart, timePart] = currentTimeString.split(' '); // Split date and time parts
    //     let [day, month, year] = datePart.split('/').map(Number); // Split and parse date parts
    //     let [hours, minutes, seconds] = timePart.split(':').map(Number); // Split and parse time parts
    //     // console.log("current ...ass....", currentTimeString);
    //     const secondIncrement = Math.floor(seconds / 3); // Increment value based on the given logic
    //     // console.log("secondIncrement....", secondIncrement);
    
    //     setInterval(() => {
    //         currentBlock += 1; 
    //         seconds += secondIncrement; 
    //         if (seconds >= 60) {
    //             minutes += Math.floor(seconds / 60);
    //             seconds = seconds % 60;
    //         }
    //         if (minutes >= 60) {
    //             hours += Math.floor(minutes / 60);
    //             minutes = minutes % 60;
    //         }
    //         if (hours >= 24) {
    //             hours = hours % 24;
    //         }
    
    //         const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`; // Format time as HH:mm:ss
    //         // console.log("Formatted time....", formattedTime);
    //         const blockData = {
    //             block: currentBlock, 
    //             time: formattedTime 
    //         };
    //         io.emit('data-server-trx-three-secound', { data: [blockData] }); // Emit the new block data
    //         console.log('Block:', blockData);
    //     }, 3000); 
    // })();
    
    
    // async function getLatestBlock() {
    //     try {
    //         const [rows] = await connection.query('SELECT * FROM trx WHERE type=1 ORDER BY id DESC LIMIT 1');
    //         console.log("rows data is ...",rows)
    //         if (rows.length > 0) {
    //             // return rows[0].block;
    //             return rows[0];
    //         } else {
    //             return 0; // or some default value if there are no blocks
    //         }
    //     } catch (error) {
    //         console.error('Error fetching latest block:', error);
    //         return 0; // or handle error as needed
    //     }
    // }
    // (async () => {
    //     console.log('Entering fetchLatestBlock function...');
    //     const latestBlock = await getLatestBlock();
    //     console.log('Latest block number is:', latestBlock);
    
    //     // let currentBlock = latestBlock;
    //     let currentBlock = latestBlock.block;
    //     let currentTime = latestBlock.time;
    //     let seconds = parseInt(currentTime.split(':').pop(), 10);
    //     console.log("secound as...",seconds)
    // const secooundDevision = Math.floor(seconds / 3);
    //     console.log("current time is .....",secooundDevision)
    
    //     setInterval(() => {
    //         currentBlock += 1; // Increment the block number by 1
    //         seconds += secooundDevision;
    //     if (seconds >= 60) {
    //         seconds = seconds % 60; // Reset seconds if 60 or more
    //     }

    //     const formattedSeconds = seconds < 10 ? '0' + seconds : seconds;
    //     console.log("formated secound....",formattedSeconds)

    //         const blockData = {
    //             block: currentBlock, // Block number
    //             time: formattedSeconds
    //         };
    //         io.emit('data-server-trx-three-secound', {data:[blockData]}); // Emit the new block data
    //         console.log('Block:', blockData);
    //     }, 3000); // Every 3 seconds
    // })();
    
  
   
    // secound 1........>>>>>>>>>>>>>>>>>>

    // const fetchAndEmitData = async () => {
    //     try {
    //         console.log("Running task every 3 seconds...");
            
    //         // Fetch the latest data
    //         const [trxgetData] = await connection.execute('SELECT * FROM trx WHERE type=1 ORDER BY id DESC LIMIT 1', []);
            
    //         if (trxgetData.length > 0) {
    //             const latestData = trxgetData[0];
                
    //             // Extract block and time
    //             const block = latestData.block;
    //             const timeString = latestData.time.split(' ')[1]; // Assuming time is in 'YYYY-MM-DD HH:MM:SS' format
    //             const seconds = parseInt(timeString.split(':')[2], 10);
    //         // Divide by 3
    //         const secoundDevision = seconds / 3;
    //             // Log the data
    //             console.log("trxdata is given..", trxgetData);
    //             console.log("Block:", block);
    //             console.log("time is  :", timeString);
    //             console.log("secound is  :", seconds);
    //             console.log("devision is  :", secoundDevision);
                
    //             // Emit the data
    //             // io.emit('data-server-trx-three-secound', { block, time: totalSeconds, result });
    //         } else {
    //             console.log("No data found");
    //         }
    //     } catch (error) {
    //         console.error('Error fetching data from API:', error);
    //     }
    // };
    
    // // Run the task every 3 seconds
    // setInterval(fetchAndEmitData, 3000);
    
    // >>>>>>>>>>>>>>>>>>>>>>>>>> secound 2....................

//     const fetchAndEmitData = async () => {
//         try {
//             console.log("Running task every 3 seconds...");
//             const [trxgetData] = await connection.execute('SELECT * FROM trx WHERE type=1 ORDER BY id DESC LIMIT 1', []);
//             const trxdata = trxgetData.map(item => {
//                 // item.hash = item.hash.slice(-4);
//                 item.time = item.time.split(' ')[1];
//                 return item;
//             });
//             console.log("trxdata is given..",trxdata)
//             console.log("Block:", trxdata[0].block);
// console.log("Time:", trxdata[0].time);
//             io.emit('data-server-trx-three-secound', { data: trxdata });
//         } catch (error) {
//             console.error('Error fetching data from API:', error);
//         }
//     };
//     setInterval(fetchAndEmitData, 3000);


    // cron.schedule('*/3 * * * *', async () => {
    //     try {
    //         const [trxgetData] = await connection.execute('SELECT * FROM trx WHERE type = 2 ORDER BY id DESC LIMIT 10', []);
    //         const trxdataThreeMinute = trxgetData.map(item => {
    //             // Update hash to show only the last 6 characters
    //             item.hash = item.hash.slice(-4);
              
    //             // Update time to show only the time part (HH:mm:ss)
    //             item.time = item.time.split(' ')[1];
              
    //             // Format period field as per your requirement
    //             const formattedPeriod = `202**${item.period.toString().slice(-4)}`;
    //             item.period = formattedPeriod;
              
    //             // Return the modified item
    //             return item;
    //           });
    //         io.emit('data-server-trxThreeMinute', { data: trxdataThreeMinute });
    //         const [trxgetperiod] = await connection.execute('SELECT * FROM trx WHERE type = 2 ORDER BY id DESC LIMIT 1', []);
    //         const trxPeriodData=trxgetperiod[0].period +1;
    //         // console.log("trx period data with + 1 value ....",trxPeriodData)
    //         io.emit('data-server-trxThreeMinute-get-period', { data: trxPeriodData });
    //         await sleep(56000);
    //         const latestBlock = await fetchLatestBlock(2, 60);
    //         // console.log("Latest block DATA IS ..:", latestBlock);
            
    //         console.log(".................");

    //         const response = await axios.get('https://codunia.com/trx.php', {
    //             params: {
    //                 blockNumber: latestBlock
    //             }
    //         });
    //         const data = response.data;
    //         // Extract required fields from the API response
    //         const block = data.BlockHeight;
    //         const hash = data.Hash;
    //         const result = data.result;
    //         const time = new Date().toISOString().slice(0, 19).replace('T', ' '); // Current timestamp
    //         const bigsmall = result <= 4 ? 'small' : 'big';
    //         const status = 1;
    //         const singleType = 2;
    //         // SQL query to insert data
    //         const uniqueID = generateUniqueID();
    //         const query = 'INSERT INTO trx (period, block, hash, result, bigsmall, time, status,type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
    //         const values = [uniqueID, block, hash, result, bigsmall, time, status, singleType]; // Assuming period can be null or auto-increment
    //         // Execute the query and handle potential errors
    //         connection.query(query, values, (err, results) => {
    //             if (err) {
    //                 console.error('Error inserting data:', err);
    //                 return;
    //             }
    //             console.log('Data inserted:', results.insertId);
    //         });
    //     } catch (error) {
    //         console.error('Error fetching data from API:', error);
    //     }
    // });

    // cron.schedule('*/5 * * * *', async () => {
    //     try {
    //         console.log("cron job working 5 .........")
    //         const [trxgetData] = await connection.execute('SELECT * FROM trx WHERE type = 3 ORDER BY id DESC LIMIT 10', []);
    //         const trxdataFiveMinute = trxgetData.map(item => {
    //             // Update hash to show only the last 6 characters
    //             item.hash = item.hash.slice(-4);
              
    //             // Update time to show only the time part (HH:mm:ss)
    //             item.time = item.time.split(' ')[1];
              
    //             // Format period field as per your requirement
    //             const formattedPeriod = `202**${item.period.toString().slice(-4)}`;
    //             item.period = formattedPeriod;
              
    //             // Return the modified item
    //             return item;
    //           });
    //         // console.log("trxdata...", trxdataFiveMinute)
    //         io.emit('data-server-trxFiveMinute', { data: trxdataFiveMinute });
    //         const [trxgetperiod] = await connection.execute('SELECT * FROM trx WHERE type = 3 ORDER BY id DESC LIMIT 1', []);
    //         console.log("trxgetperiod...",trxgetperiod[0].period);
    //         const trxPeriodData=trxgetperiod[0].period +1;
    //         // console.log("trx period data with + 1 value ....",trxPeriodData)
    //         io.emit('data-server-trxFiveMinute-get-period', { data: trxPeriodData });
    //         await sleep(56000);
    //         const latestBlock = await fetchLatestBlock(3, 100);
    //         // console.log("Latest block DATA IS ..:", latestBlock);
            
    //         console.log(".................");

    //         const response = await axios.get('https://codunia.com/trx.php', {
    //             params: {
    //                 blockNumber: latestBlock
    //             }
    //         });
    //         // Log the entire API response to debug the structure
    //         console.log('API Response:', response.data);
    //         const data = response.data;
    //         // Extract required fields from the API response
    //         const block = data.BlockHeight;
    //         const hash = data.Hash;
    //         const result = data.result;
    //         const time = new Date().toISOString().slice(0, 19).replace('T', ' '); // Current timestamp
    //         const bigsmall = result <= 4 ? 'small' : 'big';
    //         const status = 1;
    //         const singleType = 3;
    //         // SQL query to insert data
    //         const uniqueID = generateUniqueID();
    //         console.log("uniqueId .....",uniqueID)
    //         const query = 'INSERT INTO trx (period, block, hash, result, bigsmall, time, status,type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
    //         const values = [uniqueID, block, hash, result, bigsmall, time, status, singleType]; // Assuming period can be null or auto-increment
    //         // Execute the query and handle potential errors
    //         connection.query(query, values, (err, results) => {
    //             if (err) {
    //                 console.error('Error inserting data:', err);
    //                 return;
    //             }
    //             console.log('Data inserted:', results.insertId);
    //         });
    //     } catch (error) {
    //         console.error('Error fetching data from API:', error);
    //     }
    // });
    
    // cron.schedule('*/10 * * * ', async () => {
    //     try {
    //         await sleep(596000);
    //         const latestBlock = await fetchLatestBlock(4, 200);
    //         console.log("Latest block DATA IS ..:", latestBlock);
    //         console.log(".................");
    //         const response = await axios.get('https://codunia.com/trx.php', {
    //             params: {
    //                 blockNumber: latestBlock
    //             }
    //         });
    //         // Log the entire API response to debug the structure
    //         console.log('API Response:', response.data);
    //         const data = response.data;
    //         // Extract required fields from the API response
    //         const block = data.BlockHeight;
    //         const hash = data.Hash;
    //         const result = data.result;
    //         const time = new Date().toISOString().slice(0, 19).replace('T', ' '); // Current timestamp
    //         const bigsmall = result <= 4 ? 'small' : 'big';
    //         const status = 1;
    //         const fourType = 4;
    //         // SQL query to insert data
    //         const query = 'INSERT INTO trx (period, block, hash, result, bigsmall, time, status,type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
    //         const values = ['22', block, hash, result, bigsmall, time, status, fourType]; // Assuming period can be null or auto-increment
    //         // Execute the query and handle potential errors
    //         connection.query(query, values, (err, results) => {
    //             if (err) {
    //                 console.error('Error inserting data:', err);
    //                 return;
    //             }
    //             console.log('Data inserted:', results.insertId);
    //         });
    //     } catch (error) {
    //         console.error('Error fetching data from API:', error);
    //     }
    // });



    cron.schedule('*/5 * * * *', async () => {
        await winGoController.addWinGo(5);
        await winGoController.handlingWinGo1P(5);
        const [winGo1] = await connection.execute('SELECT * FROM `wingo` WHERE `game` = "wingo5" ORDER BY `id` DESC LIMIT 2 ', []);
        const data = winGo1; // Cầu mới chưa có kết quả
        io.emit('data-server', { data: data });

        await k5Controller.add5D(5);
        await k5Controller.handling5D(5);
        const [k5D] = await connection.execute('SELECT * FROM 5d WHERE `game` = 5 ORDER BY `id` DESC LIMIT 2 ', []);
        const data2 = k5D; // Cầu mới chưa có kết quả
        io.emit('data-server-5d', { data: data2, 'game': '5' });

        await k3Controller.addK3(5);
        await k3Controller.handlingK3(5);
        const [k3] = await connection.execute('SELECT * FROM k3 WHERE `game` = 5 ORDER BY `id` DESC LIMIT 2 ', []);
        const data3 = k3; // Cầu mới chưa có kết quả
        io.emit('data-server-k3', { data: data3, 'game': '5' });
    });
    cron.schedule('*/10 * * * *', async () => {
        await winGoController.addWinGo(10);
        await winGoController.handlingWinGo1P(10);
        const [winGo1] = await connection.execute('SELECT * FROM `wingo` WHERE `game` = "wingo10" ORDER BY `id` DESC LIMIT 2 ', []);
        const data = winGo1; // Cầu mới chưa có kết quả
        io.emit('data-server', { data: data });


        await k5Controller.add5D(10);
        await k5Controller.handling5D(10);
        const [k5D] = await connection.execute('SELECT * FROM 5d WHERE `game` = 10 ORDER BY `id` DESC LIMIT 2 ', []);
        const data2 = k5D; // Cầu mới chưa có kết quả
        io.emit('data-server-5d', { data: data2, 'game': '10' });

        await k3Controller.addK3(10);
        await k3Controller.handlingK3(10);
        const [k3] = await connection.execute('SELECT * FROM k3 WHERE `game` = 10 ORDER BY `id` DESC LIMIT 2 ', []);
        const data3 = k3; // Cầu mới chưa có kết quả
        io.emit('data-server-k3', { data: data3, 'game': '10' });
    });

    cron.schedule('* * 0 * * *', async () => {
        await connection.execute('UPDATE users SET roses_today = ?', [0]);
        await connection.execute('UPDATE point_list SET money = ?', [0]);
    });
}

module.exports = {
    cronJobGame1p
};